$("#example").DataTable({
  responsive: true,
});
// form 
document.addEventListener('DOMContentLoaded', function () {
  const urlParams = new URLSearchParams(window.location.search);
  const status = urlParams.get('status');

  if (status === 'success') {
      Swal.fire({
          icon: 'success',
          title: 'Request submitted!',
          text: 'Your e-book request has been submitted successfully.',
          confirmButtonText: 'OK'
      });
  } else if (status === 'error') {
      Swal.fire({
          icon: 'error',
          title: 'Oops!',
          text: 'There was an issue submitting your request. Please try again.',
          confirmButtonText: 'OK'
      });
  }
});

// Email and phone validations

  function validateForm(event) {
    var email = document.getElementById("workEmail").value;
    var phone = document.getElementById("phone").value;


    var emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    var phoneRegex = /^\d+$/;

    if (!emailRegex.test(email)) {

      Swal.fire({
        icon: 'error',
        title: 'Invalid Email',
        text: 'Please enter a valid email address.',
      });
      event.preventDefault();
      return false;
    }

    if (!phoneRegex.test(phone)) {
     
      Swal.fire({
        icon: 'error',
        title: 'Invalid Phone Number',
        text: 'Phone number should be numeric.',
      });
      event.preventDefault(); 
      return false;
    }

    return true;
  }